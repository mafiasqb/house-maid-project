import React, { useState } from "react";

function MaidRegistry() {
  const [maids, setMaids] = useState([]); // store maids
  const [showForm, setShowForm] = useState(false);
  const [newMaid, setNewMaid] = useState({ name: "", age: "", skill: "" });

  // handle form submission
  const handleAddMaid = (e) => {
    e.preventDefault();
    if (!newMaid.name) return alert("Please enter maid name");
    setMaids([...maids, newMaid]);
    setNewMaid({ name: "", age: "", skill: "" });
    setShowForm(false);
  };

  return (
    <div className="card p-4 bg-white shadow rounded">
      <h2 className="text-xl font-bold mb-2">Maid Registry</h2>

      {maids.length === 0 ? (
        <p>No maids found, add one!</p>
      ) : (
        <ul className="list-disc ml-4 mb-2">
          {maids.map((maid, index) => (
            <li key={index}>
              {maid.name} - Age: {maid.age || "N/A"} - Skill: {maid.skill || "N/A"}
            </li>
          ))}
        </ul>
      )}

      <button
        className="mt-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        onClick={() => setShowForm(!showForm)}
      >
        {showForm ? "Cancel" : "Add Maid"}
      </button>

      {showForm && (
        <form onSubmit={handleAddMaid} className="mt-2 flex flex-col gap-2">
          <input
            type="text"
            placeholder="Name"
            value={newMaid.name}
            onChange={(e) => setNewMaid({ ...newMaid, name: e.target.value })}
            className="border p-1 rounded"
          />
          <input
            type="number"
            placeholder="Age"
            value={newMaid.age}
            onChange={(e) => setNewMaid({ ...newMaid, age: e.target.value })}
            className="border p-1 rounded"
          />
          <input
            type="text"
            placeholder="Skill"
            value={newMaid.skill}
            onChange={(e) => setNewMaid({ ...newMaid, skill: e.target.value })}
            className="border p-1 rounded"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
          >
            Save Maid
          </button>
        </form>
      )}
    </div>
  );
}

export default MaidRegistry;
