import React, { useEffect, useState } from "react";
import API from "../services/api";
import "./Auth.css";

const Dashboard = () => {
  const [maids, setMaids] = useState([]);
  const [skillsOptions, setSkillsOptions] = useState([
    "Cooking",
    "Cleaning",
    "Laundry",
    "Child-Care",
    "Elder-Care",
  ]); // dynamic skills list
  const [form, setForm] = useState({
    name: "",
    phone: "",
    experience: "",
    rating: 0,
    skills: [],
  });
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const ratingOptions = [1, 2, 3, 4, 5]; // dynamic ratings list

  // Fetch maids and update skills dynamically
  useEffect(() => {
    const fetchMaids = async () => {
      try {
        const res = await API.get("/maids");
        const maidsData = res.data.maids || [];
        setMaids(maidsData);

        // Merge skills safely without dependency issues
        setSkillsOptions((prev) =>
          Array.from(new Set([...prev, ...maidsData.flatMap((m) => m.skills || [])]))
        );
      } catch (err) {
        setError("Failed to load maids");
      } finally {
        setLoading(false);
      }
    };
    fetchMaids();
  }, []); // ✅ no ESLint warning

  // Add or update maid
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const maidData = { ...form };

      if (editingId) {
        const res = await API.put(`/maids/${editingId}`, maidData);
        setMaids(
          maids.map((m) =>
            m._id === editingId || m.id === editingId ? res.data.maid || res.data : m
          )
        );
        setEditingId(null);
      } else {
        const res = await API.post("/maids", maidData);
        setMaids([...maids, res.data.maid || res.data]);

        // update dynamic skills if new skills added
        maidData.skills.forEach((s) => {
          if (!skillsOptions.includes(s)) setSkillsOptions((prev) => [...prev, s]);
        });
      }

      setForm({ name: "", phone: "", experience: "", rating: 0, skills: [] });
    } catch (err) {
      console.error("Failed to add/update maid", err);
    }
  };

  // Delete maid
  const deleteMaid = async (id) => {
    try {
      await API.delete(`/maids/${id}`);
      setMaids(maids.filter((m) => m._id !== id && m.id !== id));
    } catch (err) {
      console.error("Failed to delete maid", err);
    }
  };

  // Start editing
  const editMaid = (maid) => {
    setForm({
      name: maid.name,
      phone: maid.phone,
      experience: maid.experience,
      rating: maid.rating || 0,
      skills: maid.skills || [],
    });
    setEditingId(maid._id || maid.id);
  };

  return (
    <div className="auth-container">
      <div
        className="auth-card"
        style={{
          maxWidth: "650px",
          width: "100%",
          padding: "30px",
          borderRadius: "8px",
          boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
        }}
      >
        <h2 style={{ textAlign: "center", marginBottom: "10px" }}>Maid Registry</h2>

        {/* Average Rating */}
        {!loading && maids.length > 0 && (
          <p style={{ textAlign: "center", fontWeight: "bold", marginBottom: "20px" }}>
            Average Rating:{" "}
            {(
              maids.reduce((acc, m) => acc + (m.rating || 0), 0) / maids.length
            ).toFixed(1)}{" "}
            ⭐
          </p>
        )}

        {/* Add/Edit Form */}
        <form
          onSubmit={handleSubmit}
          style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "20px" }}
        >
          <input
            placeholder="Name"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            required
            style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }}
          />
          <input
            placeholder="Phone"
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            required
            style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }}
          />
          <input
            type="number"
            placeholder="Experience (years)"
            value={form.experience}
            onChange={(e) => setForm({ ...form, experience: e.target.value })}
            required
            style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }}
          />

          {/* Skills Checkboxes */}
          <label style={{ fontWeight: "bold", marginTop: "10px" }}>Skills:</label>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "10px", marginBottom: "10px" }}>
            {skillsOptions.map((skill) => (
              <label key={skill} style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                <input
                  type="checkbox"
                  value={skill}
                  checked={form.skills.includes(skill)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setForm({ ...form, skills: [...form.skills, skill] });
                    } else {
                      setForm({
                        ...form,
                        skills: form.skills.filter((s) => s !== skill),
                      });
                    }
                  }}
                />
                {skill}
              </label>
            ))}
          </div>

          {/* Ratings Dropdown */}
          <label style={{ fontWeight: "bold" }}>Rating:</label>
          <select
            value={form.rating}
            onChange={(e) => setForm({ ...form, rating: Number(e.target.value) })}
            style={{
              padding: "10px",
              borderRadius: "5px",
              border: "1px solid #ccc",
              cursor: "pointer",
            }}
          >
            <option value={0}>Select rating</option>
            {ratingOptions.map((r) => (
              <option key={r} value={r}>
                {r} ⭐
              </option>
            ))}
          </select>

          <button
            type="submit"
            style={{
              padding: "12px",
              borderRadius: "5px",
              border: "none",
              backgroundColor: "#007bff",
              color: "#fff",
              fontWeight: "bold",
              cursor: "pointer",
            }}
          >
            {editingId ? "Update Maid" : "Add Maid"}
          </button>
        </form>

        {/* Loading / Error / Empty */}
        {loading && <p>Loading maids...</p>}
        {error && <p style={{ color: "red" }}>{error}</p>}
        {!loading && maids.length === 0 && <p>No maids found. Add one above.</p>}
{/* Maid list as info cards */}
{maids.length > 0 && (
  <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
    {maids.map((m) => (
      <div
        key={m._id || m.id}
        style={{
          borderLeft: "5px solid #007bff", // blue left border
          borderRadius: "5px",
          padding: "15px",
          backgroundColor: "#f9f9f9",
          boxShadow: "0 2px 6px rgba(0,0,0,0.05)",
          display: "flex",
          flexDirection: "column", // ensure contents stack vertically
          justifyContent: "space-between",
          gap: "8px", // spacing inside card
        }}
      >
        <div>
          <h4 style={{ margin: "0 0 5px 0" }}>{m.name}</h4>
          <p style={{ margin: "2px 0" }}>Phone: {m.phone || "N/A"}</p>
          <p style={{ margin: "2px 0" }}>Experience: {m.experience || 0} yrs</p>
          <p style={{ margin: "2px 0" }}>
            Skills: {Array.isArray(m.skills) && m.skills.length > 0 ? m.skills.join(", ") : "Not specified"}
          </p>
          <p style={{ margin: "2px 0" }}>
            Rating: {m.rating ? "⭐".repeat(m.rating) : "No rating"}
          </p>
        </div>

        <div style={{ display: "flex", gap: "8px", marginTop: "5px" }}>
          <button
            onClick={() => editMaid(m)}
            style={{ border: "none", background: "none", cursor: "pointer", fontSize: "18px" }}
          >
            ✏️
          </button>
          <button
            onClick={() => deleteMaid(m._id || m.id)}
            style={{ border: "none", background: "none", cursor: "pointer", fontSize: "18px" }}
          >
            ❌
          </button>
        </div>
      </div>
    ))}
  </div>
)}
      </div>
    </div>
  );
};

export default Dashboard;
