const express = require("express");
const router = express.Router();
const {
  createMaid,
  getMaids,
  updateMaid,
  deleteMaid,
} = require("../controllers/maidController");
const authMiddleware = require("../middleware/authMiddleware");

router.use(authMiddleware);

router.post("/", createMaid);
router.get("/", getMaids);
router.put("/:id", updateMaid);
router.delete("/:id", deleteMaid);

module.exports = router;
