const Maid = require("../models/Maid");

// CREATE
exports.createMaid = async (req, res) => {
  try {
    const maid = await Maid.create({
      ...req.body,
      createdBy: req.user.id,
    });
    res.status(201).json(maid);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// READ
exports.getMaids = async (req, res) => {
  try {
    const maids = await Maid.find({ createdBy: req.user.id });
    res.json(maids);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// UPDATE
exports.updateMaid = async (req, res) => {
  try {
    const maid = await Maid.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    res.json(maid);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// DELETE
exports.deleteMaid = async (req, res) => {
  try {
    await Maid.findByIdAndDelete(req.params.id);
    res.json({ message: "Maid deleted" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
